package com.zbar.decode;

/**
 * author  lingfei.qi
 * time    2017/2/10 10:24
 * file    QrCodeScan1
 * desc
 */

public class Constant {
  public static final int AUTO_FOCUS = 0x11;
  public static final int DECODE = 0x22;
  public static final int DECODE_FAILED = 0x33;
  public static final int DECODE_SUCCESS = 0x44;
  public static final int RESTART_PREVIEW = 0x55;
  public static final int RESULT_SCAN_RESULT = 0x66;
  public static final int QUIT = 0x66;
  public static final String SCAN_RESULT = "scan_result";
  public static final String SHOW_MESSAGE = "show_message";
  public static final int REQ_DISPATCH_SCAN = 0x77;
  public static final int REQ_RETURN_SCAN = 0x88;
  public static final int SCAN_FAILED = 0x99;
}
